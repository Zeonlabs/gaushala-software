import React, { Component } from 'react'
import MenuBar from '../Common/MenuBar'

export default class CharityIncome extends Component {
  constructor(props) {
    super(props)

    this.state = {
         
    }
  }

  render() {
    return (
      <div>
        <MenuBar>
        <h2>Charity income page</h2>
        </MenuBar>
      </div>
    )
  }
}
