import React, { Component } from "react";
import { Form, InputNumber } from "antd";
import "./IndexTable.scss";

class Index extends Component {
  constructor(props) {
    super(props);

    this.state = {
      total: 0,
      values: ""
      // gay: 0,
      // balad: 0,
      // vacharda: 0,
      // vachardi: 0,
      // anny: 0
    };
  }
  sumValuses = obj => Object.values(obj).reduce((a, b) => a + b);

  componentDidMount() {
    if (this.props.tableType) {
      this.setState({
        total: this.props.total
      });
    }
  }

  componentDidUpdate = prevProps => {
    if (prevProps.cancel !== this.props.cancel) {
      this.props.form.resetFields();
      if (this.props.tableType) {
        this.setState({
          total: this.props.total
        });
      } else {
        this.setState({
          total: 0
        });
      }
    }
  };

  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        const total = parseInt(this.sumValuses(values), 10);
        this.props.submit(values);
        this.setState({
          total,
          values
        });
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    const { type, tableType, data } = this.props;
    return (
      <div className="animal-table-wrapper">
        <Form onChange={this.handleSubmit} className="login-form">
          <table style={{ width: "100%" }}>
            <thead>
              <tr>
                <th className="table-header">
                  {type ? "ivagata" : "paSau naao pa`kar"}
                </th>
                <th className="table-header">{type ? "rkma" : "saMKyaa"}</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="table-animal-popup-td">
                  {type ? "Gaasa" : "gaaya"}
                </td>
                <td>
                  <Form.Item>
                    {getFieldDecorator(type ? "ghas" : "gay", {
                      initialValue: type
                        ? tableType
                          ? data.item.ghas || 0
                          : 0
                        : tableType
                        ? data[0].count
                        : 0
                    })(<InputNumber className="gujarati-font" />)}
                  </Form.Item>
                </td>
              </tr>
              <tr>
                <td className="table-animal-popup-td">
                  {type ? "caarao" : "baLad"}
                </td>
                <td>
                  <Form.Item>
                    {getFieldDecorator(type ? "charo" : "balad", {
                      initialValue: type
                        ? tableType
                          ? data.item.charo || 0
                          : 0
                        : tableType
                        ? data[1].count
                        : 0
                    })(<InputNumber />)}
                  </Form.Item>
                </td>
              </tr>
              <tr>
                <td className="table-animal-popup-td">
                  {type ? "daNa" : "vaaCrDa"}
                </td>
                <td>
                  <Form.Item>
                    {getFieldDecorator(type ? "dan" : "vacharda", {
                      initialValue: type
                        ? tableType
                          ? data.item.dan || 0
                          : 0
                        : tableType
                        ? data[2].count
                        : 0
                    })(<InputNumber />)}
                  </Form.Item>
                </td>
              </tr>
              <tr>
                <td className="table-animal-popup-td">
                  {type ? "majurI" : "vaaCrDI"}
                </td>
                <td>
                  <Form.Item>
                    {getFieldDecorator(type ? "majuri" : "vachardi", {
                      initialValue: type
                        ? tableType
                          ? data.item.majuri || 0
                          : 0
                        : tableType
                        ? data[3].count
                        : 0
                    })(<InputNumber />)}
                  </Form.Item>
                </td>
              </tr>
              {type ? (
                <tr>
                  <td className="table-animal-popup-td">
                    {type ? "Dao. e dvaa" : "Anya"}
                  </td>
                  <td>
                    <Form.Item>
                      {getFieldDecorator(type ? "doctor" : "vachardi", {
                        initialValue: type
                          ? tableType
                            ? data.item.doctor || 0
                            : 0
                          : 0
                      })(<InputNumber />)}
                    </Form.Item>
                  </td>
                </tr>
              ) : (
                ""
              )}
              <tr>
                <td className="table-animal-popup-td">Anya</td>
                <td>
                  <Form.Item>
                    {getFieldDecorator(type ? "other" : "anny", {
                      initialValue: type
                        ? tableType
                          ? data.item.other || 0
                          : 0
                        : tableType
                        ? data[4].count
                        : 0
                    })(<InputNumber />)}
                  </Form.Item>
                </td>
              </tr>
            </tbody>
            <tfoot>
              <tr>
                <td className="total-box table-animal-popup-td">TaoTla</td>
                <td className="total-box  ">{this.state.total}</td>
              </tr>
            </tfoot>
          </table>
        </Form>
      </div>
    );
  }
}

const WrappedNormalLoginForm = Form.create({ name: "normal_login" })(Index);

export default WrappedNormalLoginForm;
