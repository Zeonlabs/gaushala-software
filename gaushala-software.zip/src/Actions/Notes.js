import { listing } from "../js/actions";
import { fetchUrl } from "../js/fetchUrl";
// import apiList from "../js/apiList";

export const getNotes = id => dispatch =>
  new Promise((resolve, reject) => {
    // console.log("TCL: data", id);
    fetchUrl(
      localStorage.getItem("reversePin") === "205" ? "Post" : "get",
      `/note`,
      id
    )
      .then(res => {
        dispatch({ type: listing.noteListing, payload: res.docs });
        resolve(res);
      })
      .catch(e => {
        reject(e);
      });
  });

export const addNotes = data => dispatch =>
  new Promise((resolve, reject) => {
    // console.log("TCL/: data", data);
    fetchUrl("post", `/note/add`, data)
      .then(res => {
        resolve(res);
      })
      .catch(e => {
        reject(e);
      });
  });

export const editNotes = (id, data) => dispatch =>
  new Promise((resolve, reject) => {
    // console.log("TCL: data", id);
    fetchUrl("patch", `/note/update/${id}`, data)
      .then(res => {
        resolve(res);
      })
      .catch(e => {
        reject(e);
      });
  });

export const deleteNotes = id => dispatch =>
  new Promise((resolve, reject) => {
    // console.log("TCL: data", id);
    fetchUrl("delete", `/note/delete/${id}`)
      .then(res => {
        resolve(res);
      })
      .catch(e => {
        reject(e);
      });
  });

// export const filterNotes = id => dispatch =>
//   new Promise((resolve, reject) => {
//     console.log("TCL: data", id);
//     fetchUrl("get", `/expense`, id)
//       .then(res => {
//         resolve(res);
//       })
//       .catch(e => {
//         reject(e);
//       });
//   });
