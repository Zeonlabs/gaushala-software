const routes = {
  login: "/",
  home: "/home",
  dashboard: "/dashboard",
  charity: "/charity-income",
  expences: "/expences",
  cheques: "/cheques",
  animal: "/animals",
  employees: "/employees",
  notes: "/notes",
  trustmembers: "/trust-members",
  settingpage: "/SettingPage"
};

export default routes;
